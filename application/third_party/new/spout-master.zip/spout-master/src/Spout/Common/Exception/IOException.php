<?php

namespace Box\Spout\Common\Exception;

/**
 * Class IOException
 */
class IOException extends SpoutException
{
}
